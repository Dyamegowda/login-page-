const alertBox = document.getElementById('alert-box');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const tabLogin = document.getElementById('tab-login');
const tabRegister = document.getElementById('tab-register');

function showAlert(message, type = 'error') {
  alertBox.textContent = message;
  alertBox.className = `alert ${type}`;
}

function clearAlert() {
  alertBox.textContent = '';
  alertBox.className = 'alert hidden';
}

function switchTab(tab) {
  clearAlert();
  if (tab === 'login') {
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
  } else {
    tabRegister.classList.add('active');
    tabLogin.classList.remove('active');
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
  }
}

async function handleLogin(e) {
  e.preventDefault();
  clearAlert();

  const identifier = document.getElementById('login-identifier').value.trim();
  const password = document.getElementById('login-password').value;

  const btn = document.getElementById('login-btn');
  btn.disabled = true;
  btn.textContent = 'Logging in...';

  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, password })
    });

    const data = await res.json();

    if (!res.ok) {
      showAlert(data.message || 'Login failed', 'error');
    } else {
      showAlert('Login successful! Redirecting...', 'success');
      setTimeout(() => {
        window.location.href = '/dashboard.html';
      }, 700);
    }
  } catch (error) {
    showAlert('Server unreachable or network error.', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Log In';
  }
}

async function handleRegister(e) {
  e.preventDefault();
  clearAlert();

  const username = document.getElementById('reg-username').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;

  const btn = document.getElementById('reg-btn');
  btn.disabled = true;
  btn.textContent = 'Creating account...';

  try {
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });

    const data = await res.json();

    if (!res.ok) {
      showAlert(data.message || 'Registration failed', 'error');
    } else {
      showAlert('Account created! Redirecting to dashboard...', 'success');
      setTimeout(() => {
        window.location.href = '/dashboard.html';
      }, 800);
    }
  } catch (error) {
    showAlert('Server unreachable or network error.', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Sign Up';
  }
}

// Auto-check if already logged in
async function checkCurrentSession() {
  try {
    const res = await fetch('/api/user');
    const data = await res.json();
    if (data.loggedIn) {
      window.location.href = '/dashboard.html';
    }
  } catch (err) {
    // Ignore on failure
  }
}

checkCurrentSession();
